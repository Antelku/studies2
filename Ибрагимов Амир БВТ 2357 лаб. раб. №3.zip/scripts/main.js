var myHeading = document.hover("h1");
myHeading.textContent = "Я еблан";
